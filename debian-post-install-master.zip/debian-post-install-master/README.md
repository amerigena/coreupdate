Debian Post-Install Setup Script  
================================  
  
Run this script after installing Debian to automatically 
set up a few things which people sometimes complain about 
Debian not doing during its official install process.  
  
There's no need to download it from here first, you can 
run the script by just opening a Terminal on Debian and
running the following command:  
```shell
su - -c 'apt-get update && apt-get install -y wget' && \
bash <(wget -qO - https://bit.ly/debian-post-install)
```  
  
It will prompt you for your root password to execute the 
first line, and then again to execute the second line. 
Note that this is your root password, not your regular 
user's password.  
  
If you happen to already have `wget` installed, you can just 
run the second of the above two lines.  
  
  
The script currently does the following setup steps:  
----------------------------------------------------  
  
1. Add the current user to sudo group.  
  
2. Enable the official Debian contrib and non-free apt 
repositories if they aren't already enabled.  
  
3. If on an x86_64 system, enable the i386 architecture so 
that if you want to install wine later, it might work 
properly for more things.  
  
4. Update the system, including any available dist-upgrade 
packages in the current Debian release.  
  
5. Install all available free and non-free device firmware.  
  
6. Enable the official backports repository, so you can 
install some newer software when you want to by using
the command:  
```shell
sudo apt-get -t `lsb_release -cs`-backports install <package name>
```  
  
7. Install the correct nvidia video card driver and related 
packages if you have an nvidia GPU. This will install the 
latest version of the driver and linux kernel from the 
backports apt repository, for best GPU compatibility.  
  
  
See the script here if you want to verify what it's doing: 
[debian-post-install.sh](https://gitlab.com/defcronyke/debian-post-install/-/blob/master/debian-post-install.sh)  
  
