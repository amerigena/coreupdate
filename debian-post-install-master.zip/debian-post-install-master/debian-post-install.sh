#!/bin/bash

debian_post_install_sh() { \
  su - -c 'gpasswd -a '$USER' sudo; \
  cat /etc/apt/sources.list | grep "contrib non-free" || sed -i "s/main/main contrib non-free/g" /etc/apt/sources.list; \
  uname -a | grep "x86_64"; \
  if [ $? -eq 0 ]; then dpkg --add-architecture i386; fi; \
  apt-get update && apt-get upgrade -y && apt-get dist-upgrade -y && apt-get autoremove -y && apt-get install -y lsb-release firmware-linux; \
  export DEBIAN_RELEASE_NAME=`lsb_release -cs`; \
  mkdir -p /etc/apt/sources.list.d && \
  echo -e "deb http://deb.debian.org/debian ${DEBIAN_RELEASE_NAME}-backports main contrib non-free\ndeb-src http://deb.debian.org/debian ${DEBIAN_RELEASE_NAME}-backports main contrib non-free\n" | \
    tee /etc/apt/sources.list.d/debian-backports.list && \
  apt-get update && \
  apt-get -t ${DEBIAN_RELEASE_NAME}-backports install -y nvidia-detect; \
  export NVIDIA_DRIVER_PACKAGE=`nvidia-detect 2>/dev/null | tail -n 2 | head -n 1 | xargs`; \
  echo "$NVIDIA_DRIVER_PACKAGE" | grep nvidia-; \
  if [ $? -eq 0 ]; then \
    export DEBIAN_ARCH_NAME=`uname -r | rev | cut -d- -f1 | rev`; \
    apt-get -t ${DEBIAN_RELEASE_NAME}-backports install -y build-essential linux-image-${DEBIAN_ARCH_NAME} linux-headers-${DEBIAN_ARCH_NAME} ${NVIDIA_DRIVER_PACKAGE} ${NVIDIA_DRIVER_PACKAGE}-libs:i386 && \
    apt-get autoremove -y && \
    echo "Setup finished. You need to reboot." && \
    return 0 || \
    echo "Installing nvidia drivers failed. Everything else should be fine, but you might want to install the nvidia drivers yourself afterwards."; \
  fi; \
  echo "Setup finished. You need to logout and log back in to enable sudo support."'; \
}; \
debian_post_install_sh
