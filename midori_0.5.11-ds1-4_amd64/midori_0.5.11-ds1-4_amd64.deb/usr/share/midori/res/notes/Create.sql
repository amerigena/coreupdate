CREATE TABLE IF NOT EXISTS notes
(
    id INTEGER PRIMARY KEY,
    uri TEXT,
    title TEXT,
    note_content TEXT,
    tstamp INTEGER
);
