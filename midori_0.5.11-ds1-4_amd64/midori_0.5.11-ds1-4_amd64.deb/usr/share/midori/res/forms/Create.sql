CREATE TABLE IF NOT EXISTS forms
(
    domain text,
    field text,
    value text
)
